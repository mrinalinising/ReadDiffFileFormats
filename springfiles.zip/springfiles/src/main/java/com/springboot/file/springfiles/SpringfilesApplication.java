//https://www.youtube.com/watch?v=lm2_jynHGPc&t=811s

//https://www.youtube.com/watch?v=0RdfQHI29mE&t=1024s --download excel
package com.springboot.file.springfiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringfilesApplication.class, args);
	}
}
